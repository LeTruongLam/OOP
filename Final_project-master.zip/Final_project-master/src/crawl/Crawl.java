package crawl;

public interface Crawl {
    
}
